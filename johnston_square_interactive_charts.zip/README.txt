JOHNSTON SQUARE INTERACTIVE CHARTS

1. Upload the 8 HTML charts and index.html to a PUBLIC GitHub repository.
2. In Settings > Pages, choose Deploy from a branch, main, / (root), and Save.
3. After deployment, each chart has a URL like https://USERNAME.github.io/REPOSITORY/01_total_population.html
4. In SharePoint, edit the page, add a two-column section, and add an Embed web part in each column.
5. Example embed: <iframe src="https://USERNAME.github.io/REPOSITORY/01_total_population.html" width="100%" height="550" style="border:0" title="Johnston Square population"></iframe>
6. Repeat with the other filenames. The index.html URL displays all 8 in a responsive 2-column layout.

NOTE: The data are transcribed from supplied screenshots. Vacancy margins of error are visually approximated from the screenshots, not sourced from raw ACS data; replace them with exact margins before public use. Educational attainment displayed percentages are rounded and may sum to 101% for some periods. Income data are nominal, not inflation-adjusted.

Files are standalone and contain Plotly JS; no external CDN is required.
